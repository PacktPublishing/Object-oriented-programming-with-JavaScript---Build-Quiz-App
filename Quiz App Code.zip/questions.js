var questions = [
{
	"question": "Web pages are designed using?",
	"option1" : "HTML",
	"option2": "CSS",
	"option3": "Javascript",
	"option4": "Jquery",
	"answer": 2
}, 
{
	"question": "Web pages are designed using?",
	"option1" : "HTML",
	"option2": "CSS",
	"option3": "Javascript",
	"option4": "Jquery",
	"answer": 2
},
{
	"question": "____ makes websites dynamic",
	"option1" : "CSS",
	"option2": "HTML",
	"option3": "Javascript",
	"option4": "Bootstrap",
	"answer": 3
},
{
	"question": "What is HTML used for?",
	"option1" : "Skeleton of website",
	"option2": "Design a website",
	"option3": "Make website dynamic",
	"option4": "Database of a website",
	"answer": 1
},
{
	"question": "Which CSS property changes background color?", 
	"option1": "colour",
	"option2": "bgColor",
	"option3": "color",
	"option4": "background-color",
	"answer": 4
}, 
{
	"question": "Which selector selects all the elements in CSS?", 
	"option1": "*",
	"option2": "+",
	"option3": "$",
	"option4": "#",
	"answer": 1
}, 
{
	"question": "What is the value of a in a+=b where a=10 & b=5?", 
	"option1": "10",
	"option2": "5",
	"option3": "15",
	"option4": "20",
	"answer": 3
}, 
{
	"question": "What does 'document' denote in a javascript statement?", 
	"option1": "Javascript file",
	"option2": "Css file",
	"option3": "HTML page",
	"option4": "XML document",
	"answer": 3
}, 
{
	"question": "Which function is used to calculate an expression?", 
	"option1": "calculate()",
	"option2": "calc()",
	"option3": "evaluate()",
	"option4": "eval()",
	"answer": 4
}, 
{
	"question": "How do you call a function? ", 
	"option1": "call.function_name",
	"option2": "function_name.call",
	"option3": "call(function_name)",
	"option4": "function_name()",
	"answer": 4
}, 
{
	"question": "Javascript statements should end with a ... ", 
	"option1": "Comma",
	"option2": "Semicolon",
	"option3": "Period",
	"option4": "Exclamation",
	"answer": 2
}		
];